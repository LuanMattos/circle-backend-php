import Vue from 'vue'
import VueEasyLightbox from 'vue-easy-lightbox'

Vue.use(VueEasyLightbox)
