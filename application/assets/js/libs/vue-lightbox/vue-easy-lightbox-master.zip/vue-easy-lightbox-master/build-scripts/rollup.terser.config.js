export const terserOptions = {
  sourcemap: false,
  output: {
    comments: false
  }
}
