import VueEasyLightbox from '../index'
import Vue from 'vue'

Vue.component(VueEasyLightbox.name, VueEasyLightbox)
Vue.use(VueEasyLightbox)
