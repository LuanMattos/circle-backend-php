# import-img-locally

## run this , demo in `./src/App.vue`

```bash
npm install
npm run serve

# open http://localhost:8080/
```
